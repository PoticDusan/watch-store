/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.KategorijaController;
import com.controller.ProizvodController;
import com.entity.Proizvod;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Potic-Win10
 */
@Named("productList")
@ApplicationScoped
public class ProductList {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;
    @Inject
    private ProizvodController pc;
    @Inject
    private KategorijaController kc;
    

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public void getProizvodi() {
        System.out.println("METODA getProizvodi()");
        System.out.println("PRIKUPLJAM PROIZVODE");
        List<Proizvod> lista = pc.getItems();
        System.out.println("PROIZVODI PRIKUPLJENI");
        System.out.println("PROIZVODI SE STAMPAJU: ");
        int i = 0;
        System.out.println("==============================");

        for (Proizvod p : lista) {
            p = lista.get(i);
            i++;
            System.out.println("ID:         " + p.getProizvodid());
            System.out.println("SLIKA:      " + p.getSlika());
            System.out.println("TIP:        " + p.getTip());
            System.out.println("NAZIV:      " + p.getNaziv());
            System.out.println("OPIS:       " + p.getOpis());
            System.out.println("CENA:       " + p.getCena());
            System.out.println("KOLICINA:   " + p.getKolicina());
            if (p.getStatus() == 1) {
                System.out.println("STATUS:     NA LAGERU");
            } else {
                System.out.println("STATUS:     NIJE NA LAGERU");
            }
            System.out.println("KATEGORIJA: " + p.getKategorijaid().getTip());
            System.out.println("==============================");
        }
        System.out.println("##############################");
    }

    public List<Proizvod> getAvailableProducts() {
        List<Proizvod> availableProducts = em.createNamedQuery("Proizvod.findAllAvailable").getResultList();
        return availableProducts;
    }
}
