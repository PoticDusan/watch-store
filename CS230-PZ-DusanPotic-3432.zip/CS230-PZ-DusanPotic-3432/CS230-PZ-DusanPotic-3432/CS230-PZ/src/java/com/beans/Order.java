/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.AdresaController;
import com.controller.KorisnikController;
import com.controller.KorpaController;
import com.controller.NarudzbinaController;
import com.entity.Adresa;
import com.entity.Narudzbina;
import java.io.Serializable;
import java.util.Date;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Potic-Win10
 */
@Named("order")
@SessionScoped
public class Order implements Serializable {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;

    @Inject
    private KorisnikController userController;

    @Inject
    private KorpaController cartController;

    @Inject
    private AdresaController adressController;

    @Inject
    private CartItems cartItems;
    
    @Inject
    private NarudzbinaController orderController;

    private Narudzbina selected;
    private String drzava;
    private String grad;
    private String ulica;
    private String broj;
    private String brojRacuna;

    public Narudzbina getSelected() {
        return selected;
    }

    public void setSelected(Narudzbina selected) {
        this.selected = selected;
    }

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public String getBroj() {
        return broj;
    }

    public void setBroj(String broj) {
        this.broj = broj;
    }

    public String getBrojRacuna() {
        return brojRacuna;
    }

    public void setBrojRacuna(String brojRacuna) {
        this.brojRacuna = brojRacuna;
    }

    public String createOrder() {
        System.out.println("KREIRAM NOVU NARUDZBINU");
        int orderID = 1;
        try {
            orderID = (int) em.createNamedQuery("Narudzbina.findNextId").getSingleResult();
        } catch (NullPointerException e) {
            orderID = 1;
        }

        //uzmi id kao i narudzbini
        System.out.println("KREIRAM NOVU ADRESU");
        int adressID = 1;
        try {
            adressID = (int) em.createNamedQuery("Adresa.findNextId").getSingleResult();
        } catch (NullPointerException e) {
            adressID = 1;
        }
        Adresa adress = new Adresa(adressID);
        adress.setDrzava(drzava);
        adress.setGrad(grad);
        adress.setUlica(ulica);
        adress.setBroj(broj);
        adressController.setSelected(adress);
        adressController.createAdress(adress);
        System.out.println("ADRESA KREIRANA");

        selected = new Narudzbina(orderID);
        System.out.println("NARUDZBINA ID OK");
        selected.setRacun(brojRacuna);
        System.out.println("NARUDZBINA RACUN OK");
        selected.setAdresaid(adress);
        System.out.println("NARUDZBINA ADRESA OK");
        selected.setKorisnikid(userController.getSelected());
        System.out.println("NARUDZBINA KORISNIK OK");
        selected.setKorpaid(cartController.getSelected());
        System.out.println("NARUDZBINA KORPA OK");
        System.out.println("DODAVANJE DATUMA");
        Date datum = new Date();
        selected.setDatum(datum.toString());
        System.out.println("NARUDZBINA DATUM OK");
        selected.setSuma(cartItems.getTotal());
        System.out.println("NARUDZBINA SUMA OK");
        selected.setStatus(1);
        System.out.println("NARUDZBINA STATUS OK");
        orderController.createOrder(selected);
        return "success";
        
    }
}
