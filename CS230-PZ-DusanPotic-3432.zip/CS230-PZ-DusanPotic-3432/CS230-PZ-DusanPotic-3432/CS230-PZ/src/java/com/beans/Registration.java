/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.KorisnikController;
import com.entity.Korisnik;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Potic-Win10
 */
@Named("registration")
@ApplicationScoped
public class Registration {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;

    private static final long serialVersionUID = 1L;

    @Inject
    private KorisnikController k;

    private String ime;
    private String prezime;
    private String email;
    private String password;

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String register() {
        System.out.println("METODA register()");
        try {
            System.out.println("KREIRANJE NOVOG KORISNIKA");
            int id = 1;
            try {
                id = (int) em.createNamedQuery("Korisnik.findNextId").getSingleResult();
            } catch (NullPointerException e) {
                id = 1;
            }
            System.out.println("NOVI ID: " + id);
            Korisnik user = new Korisnik(id);
            user.setIme(ime);
            user.setPrezime(prezime);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole("user");
            System.out.println("DODATI PODACI");
            if (validateUser(user)) {
                if (k.createRegister(user)) {
                    return "index";
                } else {
                    System.out.println("NIJE PROSLA REGISTRACIJA");
                    return "error";
                }
            } else {
                return "error";
            }
        } catch (NullPointerException e) {
            System.out.println("NE POSTOJI NI JEDAN KORISNIK NA SISTEMU -->> ");
            return "error";
        } catch (NoResultException e) {
            System.out.println("NE POSTOJI NI JEDAN KORISNIK NA SISTEMU -->> ");
            return "error";
        }
    }

    private boolean validateUser(Korisnik user) {
        boolean valid = false;
        try {
            user = (Korisnik) em.createNamedQuery("Korisnik.findByEmail").setParameter("email", email).getSingleResult();
            System.out.println("POSTOJI KORISNIK SA TAKVIM EMAIL-om -->> " + email);
        } catch (NoResultException e) {
            System.out.println("NE POSTOJI KORISNIK SA TAKVIM EMAIL-om -->> " + email);
            valid = true;
        }
        return valid;
    }
}
