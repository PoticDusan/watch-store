/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

/**
 *
 * @author Potic-Win10
 */
import com.controller.ProizvodController;
import com.entity.Proizvod;
import javax.enterprise.context.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;
import javax.inject.Named;

@Named("product")
@ManagedBean
//@ApplicationScopped
public class Product {

    @Inject
    private ProizvodController pc;

    public ProizvodController getPc() {
        return pc;
    }

    public void setPc(ProizvodController pc) {
        this.pc = pc;
    }

}
