/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.KorpaController;
import com.controller.ProizvodController;
import com.controller.ProizvodkorpaController;
import com.entity.Korisnik;
import com.entity.Korpa;
import com.entity.Proizvodkorpa;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Potic-Win10
 */
@Named("cartItem")
@SessionScoped
public class CartItem implements Serializable {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;

    @Inject
    private Login l;

    @Inject
    private KorpaController kc;

    @Inject
    private ProizvodkorpaController pkc;

    @Inject
    private ProizvodController pc;

    private int kolicina;

    public ProizvodkorpaController getPkc() {
        return pkc;
    }

    public void setPkc(ProizvodkorpaController pkc) {
        this.pkc = pkc;
    }

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public Login getL() {
        return l;
    }

    public void setL(Login l) {
        this.l = l;
    }

    public ProizvodController getPc() {
        return pc;
    }

    public void setPc(ProizvodController pc) {
        this.pc = pc;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public String addToCart() {
        System.out.println("_______________________________");
        System.out.println("METODA addToCart()");
        System.out.println("PROVERAVAM DA LI JE KORISNIK ULOGOVAN");

        if (isUserLogged()) {
            if (l.getRola().equals("admin")) {
                return "products_admin";
            } else {
                System.out.println("KORISNIK: " + l.getEmail() + "ULOGOVAN");
                Korisnik user = (Korisnik) em.createNamedQuery("Korisnik.findByEmail").setParameter("email", l.getEmail()).getSingleResult();
                System.out.println("KORISNIK: " + user.getEmail());
                System.out.println("PROVERAVAM KORPU KORISNIKA");
                Korpa k = getKorpaByKorisnikId(user);
                if (k != null) {
                    kc.setSelected(k);
                    System.out.println("SELEKTOVANA KORPA");
                    List<Proizvodkorpa> list = em.createNamedQuery("Proizvodkorpa.findByKorpaID").setParameter("korpaid", k).getResultList();
                    pkc.setSelectedItems(list);
                    System.out.println(pkc.getSelectedItems().toString());
                    System.out.println("PREUZETI PROIZVODI U KORPI");

                    System.out.println("PROVERAVAM DA LI SE PROIZVOD NALAZI U KORPI");
                    if (pkc.isContained(pc.getSelected())) {
                        System.out.println("PROIZVOD SE NALAZI -> ERROR");
                        return "error";
                    } else {
                        System.out.println("PROIZVOD SE NE NALAZI");
                        int idPK = 1;
                        try {
                            idPK = (int) em.createNamedQuery("Proizvodkorpa.findNextID").getSingleResult();
                        } catch (NullPointerException e) {
                            idPK = 1;
                        }
                        System.out.println("NOVI ID: " + idPK);
                        Proizvodkorpa pk = new Proizvodkorpa(idPK);
                        pk.setKorpaid(k);
                        System.out.println("SETOVANA KORPA");
                        pk.setProizvodid(pc.getSelected());
                        System.out.println("SETOVAN PROIZVOD");
                        pk.setKolicina(1);////////////////////////// NAMESTI KOLICINU ////////////////////////////
                        System.out.println("SETOVANA KOLICINA");
                        pkc.createProizvodkorpa(pk);
                        pkc.addSelectedItem(pk);
                        System.out.println("KREIRANA PROIZVOD-KORPA");
                        return "cart";
                    }
                } else {
                    try {
                        System.out.println("KREIRANJE NOVE KORPE..");

                        int id = 1;
                        try {
                            id = (int) em.createNamedQuery("Korpa.findNextId").getSingleResult();
                        } catch (NullPointerException e) {
                            id = 1;
                        }

                        System.out.println("NOVI ID: " + id);
                        Korpa cart = new Korpa(id);
                        System.out.println("PRONADJEN KORISNIK ");
                        cart.setKorisnikid(user);
                        kc.createCart(cart);
                        kc.setSelected(cart);
                        System.out.println("KREIRANA KORPA");

                        System.out.println("KREIRA SE PROIZVOD-KORPA");
                        int idPK = 1;
                        try {
                            idPK = (int) em.createNamedQuery("Proizvodkorpa.findNextID").getSingleResult();
                        } catch (NullPointerException e) {
                            idPK = 1;
                        }

                        System.out.println("NOVI ID: " + idPK);
                        Proizvodkorpa pk = new Proizvodkorpa(idPK);
                        pk.setKorpaid(cart);
                        System.out.println("DODATA KORPA");
                        pk.setProizvodid(pc.getSelected());
                        System.out.println("DODAT PROIZVOD");
                        pkc.createProizvodkorpa(pk);
                        pkc.addSelectedItem(pk);
                        System.out.println("KREIRANA PROIZVOD-KORPA");
                        return "cart";
                    } catch (Exception e) {
                        System.out.println("NE POSTOJI NI JEDANA KORPA NA SISTEMU -->> ");
                        e.printStackTrace();
                        return "error";
                    }
                }
            }
        } else {
            System.out.println("KORISNIK NIJE ULOGOVAN");
            return "login";
        }
    }

    public boolean hasCart(Korisnik k) {
        try {
            Korpa cart = (Korpa) em.createNamedQuery("Korpa.findByKorisnikId").setParameter("korisnikid", k.getKorisnikid()).getSingleResult();
            return true;
        } catch (NullPointerException e) {
            return false;
        }
    }

    public Korpa getKorpaByKorisnikId(Korisnik k) {
        try {
            Korpa cart = (Korpa) em.createNamedQuery("Korpa.findByKorisnikId").setParameter("korisnikid", k).getSingleResult();
            return cart;
        } catch (NoResultException | NullPointerException e) {
            return null;
        }
    }

    public boolean isUserLogged() {
        return l.isLoggedIn();
    }
}
