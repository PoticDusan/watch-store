/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.KategorijaController;
import com.controller.KorisnikController;
import com.controller.KorpaController;
import com.controller.ProizvodController;
import com.controller.ProizvodkorpaController;
import com.entity.Korisnik;
import com.entity.Korpa;
import com.entity.Proizvod;
import com.entity.Proizvodkorpa;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Potic-Win10
 */
@Named("cartItems")
@SessionScoped
public class CartItems implements Serializable {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;
    @Inject
    private Login l;
    @Inject
    private ProizvodkorpaController pkc;
    @Inject
    private ProizvodController pc;
    @Inject
    private KorpaController kc;
    @Inject
    private KorisnikController uc;

    int kolicina;
    private List<Proizvod> list;

    private float total;

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    public float getTotal() {
        total = 0;
        for (Proizvod p : list) {
            total = total + p.getCena();
        }
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public List<Proizvod> getSelectedProductList() {
        if (isUserLogged()) {
            try {
                list = new ArrayList<>();
                int i = 1;
                kc.setSelected((Korpa) em.createNamedQuery("Korpa.findByKorisnikId").setParameter("korisnikid", uc.getSelected()).getSingleResult());
                List<Proizvodkorpa> pkList = em.createNamedQuery("Proizvodkorpa.findByKorpaID").setParameter("korpaid", kc.getSelected()).getResultList();
                pkc.setSelectedItems(pkList);
                total = 0;
                System.out.println("LISTA PROIZVODA U KORPI:");
                for (Proizvodkorpa pk : pkc.getSelectedItems()) {
                    Proizvod p = pk.getProizvodid();
                    System.out.println("PROIZVOD " + i + ": " + p.getNaziv());
                    list.add(p);
                    total += p.getCena();
                }
                System.out.println("END");
                return list;
            } catch (NullPointerException e) {
                System.out.println("NULL POINTER EXCEPTION");
                return null;
            }
        } else {
            System.out.println("KORISNIK NIJE ULOGOVAN");
            System.out.println("VRSIM PREUSMERAVANJE..");
            FacesContext context = FacesContext.getCurrentInstance();
            HttpServletRequest origRequest = (HttpServletRequest) context.getExternalContext().getRequest();
            String contextPath = origRequest.getContextPath();
            try {
                FacesContext.getCurrentInstance().getExternalContext()
                        .redirect(contextPath + "/faces/login.xhtml");
            } catch (IOException e) {
                System.out.println("PREUSMERAVANJE NIJE USPELO");
                e.printStackTrace();
            }
            return null;
        }
    }

    public boolean isUserLogged() {
        return l.isLoggedIn();
    }

    public void updateCena(Proizvod p) {
        total += list.get(p.getProizvodid()).getCena();
        System.out.println("PRICE UPDATED");
    }

    public void setKolicina(ValueChangeEvent event) {
        kolicina = (Integer) event.getNewValue();
    }

    public void refreshItems() {
        System.out.println("REFRESH LIST");
        int i = 1;
        kc.setSelected((Korpa) em.createNamedQuery("Korpa.findByKorisnikId").setParameter("korisnikid", uc.getSelected()).getSingleResult());
        List<Proizvodkorpa> pkList = em.createNamedQuery("Proizvodkorpa.findByKorpaID").setParameter("korpaid", kc.getSelected()).getResultList();
        pkc.setSelectedItems(pkList);
        total = 0;
        System.out.println("LISTA PROIZVODA U KORPI:");
        for (Proizvodkorpa pk : pkc.getSelectedItems()) {
            Proizvod p = pk.getProizvodid();
            System.out.println("PROIZVOD " + i + ": " + p.getNaziv());
            list.add(p);
            total += p.getCena();
        }
        System.out.println("REFRESH END");
    }

    public void updateKolicina(Proizvod p) {
        Query updateKolicina = em.createNamedQuery("UPDATE Proizvodkorpa SET kolicina =" + kolicina + " WHERE korpaid = " + kc.getSelected().getKorpaid() + "AND proizvodid = " + p.getProizvodid());
        refreshItems();
    }

    public void removeCart() {
        pkc.deletAll();
    }
    
}
