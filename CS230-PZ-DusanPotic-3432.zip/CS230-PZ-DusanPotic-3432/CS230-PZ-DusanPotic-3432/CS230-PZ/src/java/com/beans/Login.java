/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.beans;

import com.controller.KorisnikController;
import com.entity.Korisnik;
import com.util.SessionUtil;
import javax.enterprise.context.ApplicationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Potic-Win10
 */
@Named
@ApplicationScoped
public class Login {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;

    private static final long serialVersionUID = 1L;
    @Inject
    private KorisnikController kc;
    private String email;
    private String password;
    @Inject
    private CartItems ci;

    private String rola = "none";
    private boolean loggedIn;

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRola() {
        return rola;
    }

    public void setRola(String rola) {
        this.rola = rola;
    }

    public String login() {
        Korisnik user = null;
        boolean valid = false;

        System.out.println("METODA login()");
        try {
            user = (Korisnik) em.createNamedQuery("Korisnik.findByEmail").setParameter("email", email).getSingleResult();
            System.out.println("USER FOUND EMAIL -->> " + email);
            valid = validateUser(user);
        } catch (NoResultException e) {
            System.out.println("NE POSTOJI KORISNIK SA EMAIL-om -->> " + email);
            valid = false;
        }

        if (valid) {
            HttpSession session = SessionUtil.getSession();
            session.setMaxInactiveInterval(7 * 86400);

            System.out.println("KREIRAM SESIJU");
            System.out.println("ID SESIJE: " + session.getId());
            session.setAttribute("email", user.getEmail());
            System.out.println("SETUJEMO ATRIBUT SESIJE -user- U: " + user.getEmail());
            System.out.println("ATRIBUT SESIJE -user- : " + session.getAttribute("email"));

            session.setAttribute("role", user.getRole());
            System.out.println("SETUJEMO ATRIBUT SESIJE -user- U: " + user.getRole());
            System.out.println("ATRIBUT SESIJE -user- : " + session.getAttribute("role"));
            /*
            session.setAttribute("ime", user.getIme());
            System.out.println("SETUJEMO ATRIBUT SESIJE -user- U: " + user.getIme());
            System.out.println("ATRIBUT SESIJE -user- : " + session.getAttribute("ime"));

            session.setAttribute("prezime", user.getPrezime());
            System.out.println("SETUJEMO ATRIBUT SESIJE -user- U: " + user.getPrezime());
            System.out.println("ATRIBUT SESIJE -user- : " + session.getAttribute("prezime"));
             */
            rola = user.getRole();
            loggedIn = true;
            kc.setSelected(user);
            System.out.println("USER IS NOW ONLINE");

            switch (rola) {
                case "admin":
                    System.out.println("TIP ROLE: ADMIN");
                    return "admin";
                case "user":
                    System.out.println("TIP ROLE: USER");
                    return "user";
                default:
                    System.out.println("TIP ROLE: VIEWER");
                    return "viewer";
            }
        } else {
            System.out.println("USER IS INVALID");
            System.out.println("GOING BACK TO LOGIN PAGE");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("BAD REQUEST", "Molimo da proverite podatke i pokusate ponovo."));
            return "login";
        }
    }

    private boolean validateUser(Korisnik user) {
        if (user.getPassword().equals(password)) {
            System.out.println("PASSWORD IS CORRECT");
            return true;
        } else {
            System.out.println("PASSWORD IS INVALID");
            return false;
        }
    }

    public String logout() {
        clearData();
        System.out.println("NAVIGATING TO INDEX");
        return "index";
    }

    private void clearData() {
        System.out.println("CLEARING DATA");
        email = "";
        System.out.println("EMAIL CLEAN");
        password = "";
        System.out.println("PASSWORD CLEAN");
        rola = "none";
        System.out.println("ROLA CLEAN");
        kc.setSelected(null);
        System.out.println("SELECTED CLEAN");
        ci.removeCart();
        System.out.println("REMOVING CART CLEAN");
        loggedIn = false;
        System.out.println("LOGGED IN SET FALSE");
    }
}
