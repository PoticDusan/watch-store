/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.IllegalOrphanException;
import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Korisnik;
import com.entity.Korpa;
import com.entity.Narudzbina;
import java.util.ArrayList;
import java.util.List;
import com.entity.Proizvodkorpa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class KorpaJpaController implements Serializable {

    public KorpaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Korpa korpa) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (korpa.getNarudzbinaList() == null) {
            korpa.setNarudzbinaList(new ArrayList<Narudzbina>());
        }
        if (korpa.getProizvodkorpaList() == null) {
            korpa.setProizvodkorpaList(new ArrayList<Proizvodkorpa>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik korisnikid = korpa.getKorisnikid();
            if (korisnikid != null) {
                korisnikid = em.getReference(korisnikid.getClass(), korisnikid.getKorisnikid());
                korpa.setKorisnikid(korisnikid);
            }
            List<Narudzbina> attachedNarudzbinaList = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNarudzbinaToAttach : korpa.getNarudzbinaList()) {
                narudzbinaListNarudzbinaToAttach = em.getReference(narudzbinaListNarudzbinaToAttach.getClass(), narudzbinaListNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaList.add(narudzbinaListNarudzbinaToAttach);
            }
            korpa.setNarudzbinaList(attachedNarudzbinaList);
            List<Proizvodkorpa> attachedProizvodkorpaList = new ArrayList<Proizvodkorpa>();
            for (Proizvodkorpa proizvodkorpaListProizvodkorpaToAttach : korpa.getProizvodkorpaList()) {
                proizvodkorpaListProizvodkorpaToAttach = em.getReference(proizvodkorpaListProizvodkorpaToAttach.getClass(), proizvodkorpaListProizvodkorpaToAttach.getProizvodkorpaid());
                attachedProizvodkorpaList.add(proizvodkorpaListProizvodkorpaToAttach);
            }
            korpa.setProizvodkorpaList(attachedProizvodkorpaList);
            em.persist(korpa);
            if (korisnikid != null) {
                korisnikid.getKorpaList().add(korpa);
                korisnikid = em.merge(korisnikid);
            }
            for (Narudzbina narudzbinaListNarudzbina : korpa.getNarudzbinaList()) {
                Korpa oldKorpaidOfNarudzbinaListNarudzbina = narudzbinaListNarudzbina.getKorpaid();
                narudzbinaListNarudzbina.setKorpaid(korpa);
                narudzbinaListNarudzbina = em.merge(narudzbinaListNarudzbina);
                if (oldKorpaidOfNarudzbinaListNarudzbina != null) {
                    oldKorpaidOfNarudzbinaListNarudzbina.getNarudzbinaList().remove(narudzbinaListNarudzbina);
                    oldKorpaidOfNarudzbinaListNarudzbina = em.merge(oldKorpaidOfNarudzbinaListNarudzbina);
                }
            }
            for (Proizvodkorpa proizvodkorpaListProizvodkorpa : korpa.getProizvodkorpaList()) {
                Korpa oldKorpaidOfProizvodkorpaListProizvodkorpa = proizvodkorpaListProizvodkorpa.getKorpaid();
                proizvodkorpaListProizvodkorpa.setKorpaid(korpa);
                proizvodkorpaListProizvodkorpa = em.merge(proizvodkorpaListProizvodkorpa);
                if (oldKorpaidOfProizvodkorpaListProizvodkorpa != null) {
                    oldKorpaidOfProizvodkorpaListProizvodkorpa.getProizvodkorpaList().remove(proizvodkorpaListProizvodkorpa);
                    oldKorpaidOfProizvodkorpaListProizvodkorpa = em.merge(oldKorpaidOfProizvodkorpaListProizvodkorpa);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findKorpa(korpa.getKorpaid()) != null) {
                throw new PreexistingEntityException("Korpa " + korpa + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Korpa korpa) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korpa persistentKorpa = em.find(Korpa.class, korpa.getKorpaid());
            Korisnik korisnikidOld = persistentKorpa.getKorisnikid();
            Korisnik korisnikidNew = korpa.getKorisnikid();
            List<Narudzbina> narudzbinaListOld = persistentKorpa.getNarudzbinaList();
            List<Narudzbina> narudzbinaListNew = korpa.getNarudzbinaList();
            List<Proizvodkorpa> proizvodkorpaListOld = persistentKorpa.getProizvodkorpaList();
            List<Proizvodkorpa> proizvodkorpaListNew = korpa.getProizvodkorpaList();
            List<String> illegalOrphanMessages = null;
            for (Narudzbina narudzbinaListOldNarudzbina : narudzbinaListOld) {
                if (!narudzbinaListNew.contains(narudzbinaListOldNarudzbina)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Narudzbina " + narudzbinaListOldNarudzbina + " since its korpaid field is not nullable.");
                }
            }
            for (Proizvodkorpa proizvodkorpaListOldProizvodkorpa : proizvodkorpaListOld) {
                if (!proizvodkorpaListNew.contains(proizvodkorpaListOldProizvodkorpa)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Proizvodkorpa " + proizvodkorpaListOldProizvodkorpa + " since its korpaid field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (korisnikidNew != null) {
                korisnikidNew = em.getReference(korisnikidNew.getClass(), korisnikidNew.getKorisnikid());
                korpa.setKorisnikid(korisnikidNew);
            }
            List<Narudzbina> attachedNarudzbinaListNew = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNewNarudzbinaToAttach : narudzbinaListNew) {
                narudzbinaListNewNarudzbinaToAttach = em.getReference(narudzbinaListNewNarudzbinaToAttach.getClass(), narudzbinaListNewNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaListNew.add(narudzbinaListNewNarudzbinaToAttach);
            }
            narudzbinaListNew = attachedNarudzbinaListNew;
            korpa.setNarudzbinaList(narudzbinaListNew);
            List<Proizvodkorpa> attachedProizvodkorpaListNew = new ArrayList<Proizvodkorpa>();
            for (Proizvodkorpa proizvodkorpaListNewProizvodkorpaToAttach : proizvodkorpaListNew) {
                proizvodkorpaListNewProizvodkorpaToAttach = em.getReference(proizvodkorpaListNewProizvodkorpaToAttach.getClass(), proizvodkorpaListNewProizvodkorpaToAttach.getProizvodkorpaid());
                attachedProizvodkorpaListNew.add(proizvodkorpaListNewProizvodkorpaToAttach);
            }
            proizvodkorpaListNew = attachedProizvodkorpaListNew;
            korpa.setProizvodkorpaList(proizvodkorpaListNew);
            korpa = em.merge(korpa);
            if (korisnikidOld != null && !korisnikidOld.equals(korisnikidNew)) {
                korisnikidOld.getKorpaList().remove(korpa);
                korisnikidOld = em.merge(korisnikidOld);
            }
            if (korisnikidNew != null && !korisnikidNew.equals(korisnikidOld)) {
                korisnikidNew.getKorpaList().add(korpa);
                korisnikidNew = em.merge(korisnikidNew);
            }
            for (Narudzbina narudzbinaListNewNarudzbina : narudzbinaListNew) {
                if (!narudzbinaListOld.contains(narudzbinaListNewNarudzbina)) {
                    Korpa oldKorpaidOfNarudzbinaListNewNarudzbina = narudzbinaListNewNarudzbina.getKorpaid();
                    narudzbinaListNewNarudzbina.setKorpaid(korpa);
                    narudzbinaListNewNarudzbina = em.merge(narudzbinaListNewNarudzbina);
                    if (oldKorpaidOfNarudzbinaListNewNarudzbina != null && !oldKorpaidOfNarudzbinaListNewNarudzbina.equals(korpa)) {
                        oldKorpaidOfNarudzbinaListNewNarudzbina.getNarudzbinaList().remove(narudzbinaListNewNarudzbina);
                        oldKorpaidOfNarudzbinaListNewNarudzbina = em.merge(oldKorpaidOfNarudzbinaListNewNarudzbina);
                    }
                }
            }
            for (Proizvodkorpa proizvodkorpaListNewProizvodkorpa : proizvodkorpaListNew) {
                if (!proizvodkorpaListOld.contains(proizvodkorpaListNewProizvodkorpa)) {
                    Korpa oldKorpaidOfProizvodkorpaListNewProizvodkorpa = proizvodkorpaListNewProizvodkorpa.getKorpaid();
                    proizvodkorpaListNewProizvodkorpa.setKorpaid(korpa);
                    proizvodkorpaListNewProizvodkorpa = em.merge(proizvodkorpaListNewProizvodkorpa);
                    if (oldKorpaidOfProizvodkorpaListNewProizvodkorpa != null && !oldKorpaidOfProizvodkorpaListNewProizvodkorpa.equals(korpa)) {
                        oldKorpaidOfProizvodkorpaListNewProizvodkorpa.getProizvodkorpaList().remove(proizvodkorpaListNewProizvodkorpa);
                        oldKorpaidOfProizvodkorpaListNewProizvodkorpa = em.merge(oldKorpaidOfProizvodkorpaListNewProizvodkorpa);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = korpa.getKorpaid();
                if (findKorpa(id) == null) {
                    throw new NonexistentEntityException("The korpa with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korpa korpa;
            try {
                korpa = em.getReference(Korpa.class, id);
                korpa.getKorpaid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The korpa with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Narudzbina> narudzbinaListOrphanCheck = korpa.getNarudzbinaList();
            for (Narudzbina narudzbinaListOrphanCheckNarudzbina : narudzbinaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korpa (" + korpa + ") cannot be destroyed since the Narudzbina " + narudzbinaListOrphanCheckNarudzbina + " in its narudzbinaList field has a non-nullable korpaid field.");
            }
            List<Proizvodkorpa> proizvodkorpaListOrphanCheck = korpa.getProizvodkorpaList();
            for (Proizvodkorpa proizvodkorpaListOrphanCheckProizvodkorpa : proizvodkorpaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korpa (" + korpa + ") cannot be destroyed since the Proizvodkorpa " + proizvodkorpaListOrphanCheckProizvodkorpa + " in its proizvodkorpaList field has a non-nullable korpaid field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Korisnik korisnikid = korpa.getKorisnikid();
            if (korisnikid != null) {
                korisnikid.getKorpaList().remove(korpa);
                korisnikid = em.merge(korisnikid);
            }
            em.remove(korpa);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Korpa> findKorpaEntities() {
        return findKorpaEntities(true, -1, -1);
    }

    public List<Korpa> findKorpaEntities(int maxResults, int firstResult) {
        return findKorpaEntities(false, maxResults, firstResult);
    }

    private List<Korpa> findKorpaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Korpa.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Korpa findKorpa(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Korpa.class, id);
        } finally {
            em.close();
        }
    }

    public int getKorpaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Korpa> rt = cq.from(Korpa.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
