/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.IllegalOrphanException;
import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Kategorija;
import com.entity.Proizvod;
import com.entity.Proizvodkorpa;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class ProizvodJpaController implements Serializable {

    public ProizvodJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Proizvod proizvod) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (proizvod.getProizvodkorpaList() == null) {
            proizvod.setProizvodkorpaList(new ArrayList<Proizvodkorpa>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija kategorijaid = proizvod.getKategorijaid();
            if (kategorijaid != null) {
                kategorijaid = em.getReference(kategorijaid.getClass(), kategorijaid.getKategorijaid());
                proizvod.setKategorijaid(kategorijaid);
            }
            List<Proizvodkorpa> attachedProizvodkorpaList = new ArrayList<Proizvodkorpa>();
            for (Proizvodkorpa proizvodkorpaListProizvodkorpaToAttach : proizvod.getProizvodkorpaList()) {
                proizvodkorpaListProizvodkorpaToAttach = em.getReference(proizvodkorpaListProizvodkorpaToAttach.getClass(), proizvodkorpaListProizvodkorpaToAttach.getProizvodkorpaid());
                attachedProizvodkorpaList.add(proizvodkorpaListProizvodkorpaToAttach);
            }
            proizvod.setProizvodkorpaList(attachedProizvodkorpaList);
            em.persist(proizvod);
            if (kategorijaid != null) {
                kategorijaid.getProizvodList().add(proizvod);
                kategorijaid = em.merge(kategorijaid);
            }
            for (Proizvodkorpa proizvodkorpaListProizvodkorpa : proizvod.getProizvodkorpaList()) {
                Proizvod oldProizvodidOfProizvodkorpaListProizvodkorpa = proizvodkorpaListProizvodkorpa.getProizvodid();
                proizvodkorpaListProizvodkorpa.setProizvodid(proizvod);
                proizvodkorpaListProizvodkorpa = em.merge(proizvodkorpaListProizvodkorpa);
                if (oldProizvodidOfProizvodkorpaListProizvodkorpa != null) {
                    oldProizvodidOfProizvodkorpaListProizvodkorpa.getProizvodkorpaList().remove(proizvodkorpaListProizvodkorpa);
                    oldProizvodidOfProizvodkorpaListProizvodkorpa = em.merge(oldProizvodidOfProizvodkorpaListProizvodkorpa);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findProizvod(proizvod.getProizvodid()) != null) {
                throw new PreexistingEntityException("Proizvod " + proizvod + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Proizvod proizvod) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Proizvod persistentProizvod = em.find(Proizvod.class, proizvod.getProizvodid());
            Kategorija kategorijaidOld = persistentProizvod.getKategorijaid();
            Kategorija kategorijaidNew = proizvod.getKategorijaid();
            List<Proizvodkorpa> proizvodkorpaListOld = persistentProizvod.getProizvodkorpaList();
            List<Proizvodkorpa> proizvodkorpaListNew = proizvod.getProizvodkorpaList();
            List<String> illegalOrphanMessages = null;
            for (Proizvodkorpa proizvodkorpaListOldProizvodkorpa : proizvodkorpaListOld) {
                if (!proizvodkorpaListNew.contains(proizvodkorpaListOldProizvodkorpa)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Proizvodkorpa " + proizvodkorpaListOldProizvodkorpa + " since its proizvodid field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (kategorijaidNew != null) {
                kategorijaidNew = em.getReference(kategorijaidNew.getClass(), kategorijaidNew.getKategorijaid());
                proizvod.setKategorijaid(kategorijaidNew);
            }
            List<Proizvodkorpa> attachedProizvodkorpaListNew = new ArrayList<Proizvodkorpa>();
            for (Proizvodkorpa proizvodkorpaListNewProizvodkorpaToAttach : proizvodkorpaListNew) {
                proizvodkorpaListNewProizvodkorpaToAttach = em.getReference(proizvodkorpaListNewProizvodkorpaToAttach.getClass(), proizvodkorpaListNewProizvodkorpaToAttach.getProizvodkorpaid());
                attachedProizvodkorpaListNew.add(proizvodkorpaListNewProizvodkorpaToAttach);
            }
            proizvodkorpaListNew = attachedProizvodkorpaListNew;
            proizvod.setProizvodkorpaList(proizvodkorpaListNew);
            proizvod = em.merge(proizvod);
            if (kategorijaidOld != null && !kategorijaidOld.equals(kategorijaidNew)) {
                kategorijaidOld.getProizvodList().remove(proizvod);
                kategorijaidOld = em.merge(kategorijaidOld);
            }
            if (kategorijaidNew != null && !kategorijaidNew.equals(kategorijaidOld)) {
                kategorijaidNew.getProizvodList().add(proizvod);
                kategorijaidNew = em.merge(kategorijaidNew);
            }
            for (Proizvodkorpa proizvodkorpaListNewProizvodkorpa : proizvodkorpaListNew) {
                if (!proizvodkorpaListOld.contains(proizvodkorpaListNewProizvodkorpa)) {
                    Proizvod oldProizvodidOfProizvodkorpaListNewProizvodkorpa = proizvodkorpaListNewProizvodkorpa.getProizvodid();
                    proizvodkorpaListNewProizvodkorpa.setProizvodid(proizvod);
                    proizvodkorpaListNewProizvodkorpa = em.merge(proizvodkorpaListNewProizvodkorpa);
                    if (oldProizvodidOfProizvodkorpaListNewProizvodkorpa != null && !oldProizvodidOfProizvodkorpaListNewProizvodkorpa.equals(proizvod)) {
                        oldProizvodidOfProizvodkorpaListNewProizvodkorpa.getProizvodkorpaList().remove(proizvodkorpaListNewProizvodkorpa);
                        oldProizvodidOfProizvodkorpaListNewProizvodkorpa = em.merge(oldProizvodidOfProizvodkorpaListNewProizvodkorpa);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = proizvod.getProizvodid();
                if (findProizvod(id) == null) {
                    throw new NonexistentEntityException("The proizvod with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Proizvod proizvod;
            try {
                proizvod = em.getReference(Proizvod.class, id);
                proizvod.getProizvodid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The proizvod with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Proizvodkorpa> proizvodkorpaListOrphanCheck = proizvod.getProizvodkorpaList();
            for (Proizvodkorpa proizvodkorpaListOrphanCheckProizvodkorpa : proizvodkorpaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Proizvod (" + proizvod + ") cannot be destroyed since the Proizvodkorpa " + proizvodkorpaListOrphanCheckProizvodkorpa + " in its proizvodkorpaList field has a non-nullable proizvodid field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Kategorija kategorijaid = proizvod.getKategorijaid();
            if (kategorijaid != null) {
                kategorijaid.getProizvodList().remove(proizvod);
                kategorijaid = em.merge(kategorijaid);
            }
            em.remove(proizvod);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Proizvod> findProizvodEntities() {
        return findProizvodEntities(true, -1, -1);
    }

    public List<Proizvod> findProizvodEntities(int maxResults, int firstResult) {
        return findProizvodEntities(false, maxResults, firstResult);
    }

    private List<Proizvod> findProizvodEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Proizvod.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Proizvod findProizvod(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Proizvod.class, id);
        } finally {
            em.close();
        }
    }

    public int getProizvodCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Proizvod> rt = cq.from(Proizvod.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
