/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Korpa;
import com.entity.Proizvod;
import com.entity.Proizvodkorpa;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class ProizvodkorpaJpaController implements Serializable {

    public ProizvodkorpaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Proizvodkorpa proizvodkorpa) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korpa korpaid = proizvodkorpa.getKorpaid();
            if (korpaid != null) {
                korpaid = em.getReference(korpaid.getClass(), korpaid.getKorpaid());
                proizvodkorpa.setKorpaid(korpaid);
            }
            Proizvod proizvodid = proizvodkorpa.getProizvodid();
            if (proizvodid != null) {
                proizvodid = em.getReference(proizvodid.getClass(), proizvodid.getProizvodid());
                proizvodkorpa.setProizvodid(proizvodid);
            }
            em.persist(proizvodkorpa);
            if (korpaid != null) {
                korpaid.getProizvodkorpaList().add(proizvodkorpa);
                korpaid = em.merge(korpaid);
            }
            if (proizvodid != null) {
                proizvodid.getProizvodkorpaList().add(proizvodkorpa);
                proizvodid = em.merge(proizvodid);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findProizvodkorpa(proizvodkorpa.getProizvodkorpaid()) != null) {
                throw new PreexistingEntityException("Proizvodkorpa " + proizvodkorpa + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Proizvodkorpa proizvodkorpa) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Proizvodkorpa persistentProizvodkorpa = em.find(Proizvodkorpa.class, proizvodkorpa.getProizvodkorpaid());
            Korpa korpaidOld = persistentProizvodkorpa.getKorpaid();
            Korpa korpaidNew = proizvodkorpa.getKorpaid();
            Proizvod proizvodidOld = persistentProizvodkorpa.getProizvodid();
            Proizvod proizvodidNew = proizvodkorpa.getProizvodid();
            if (korpaidNew != null) {
                korpaidNew = em.getReference(korpaidNew.getClass(), korpaidNew.getKorpaid());
                proizvodkorpa.setKorpaid(korpaidNew);
            }
            if (proizvodidNew != null) {
                proizvodidNew = em.getReference(proizvodidNew.getClass(), proizvodidNew.getProizvodid());
                proizvodkorpa.setProizvodid(proizvodidNew);
            }
            proizvodkorpa = em.merge(proizvodkorpa);
            if (korpaidOld != null && !korpaidOld.equals(korpaidNew)) {
                korpaidOld.getProizvodkorpaList().remove(proizvodkorpa);
                korpaidOld = em.merge(korpaidOld);
            }
            if (korpaidNew != null && !korpaidNew.equals(korpaidOld)) {
                korpaidNew.getProizvodkorpaList().add(proizvodkorpa);
                korpaidNew = em.merge(korpaidNew);
            }
            if (proizvodidOld != null && !proizvodidOld.equals(proizvodidNew)) {
                proizvodidOld.getProizvodkorpaList().remove(proizvodkorpa);
                proizvodidOld = em.merge(proizvodidOld);
            }
            if (proizvodidNew != null && !proizvodidNew.equals(proizvodidOld)) {
                proizvodidNew.getProizvodkorpaList().add(proizvodkorpa);
                proizvodidNew = em.merge(proizvodidNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = proizvodkorpa.getProizvodkorpaid();
                if (findProizvodkorpa(id) == null) {
                    throw new NonexistentEntityException("The proizvodkorpa with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Proizvodkorpa proizvodkorpa;
            try {
                proizvodkorpa = em.getReference(Proizvodkorpa.class, id);
                proizvodkorpa.getProizvodkorpaid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The proizvodkorpa with id " + id + " no longer exists.", enfe);
            }
            Korpa korpaid = proizvodkorpa.getKorpaid();
            if (korpaid != null) {
                korpaid.getProizvodkorpaList().remove(proizvodkorpa);
                korpaid = em.merge(korpaid);
            }
            Proizvod proizvodid = proizvodkorpa.getProizvodid();
            if (proizvodid != null) {
                proizvodid.getProizvodkorpaList().remove(proizvodkorpa);
                proizvodid = em.merge(proizvodid);
            }
            em.remove(proizvodkorpa);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Proizvodkorpa> findProizvodkorpaEntities() {
        return findProizvodkorpaEntities(true, -1, -1);
    }

    public List<Proizvodkorpa> findProizvodkorpaEntities(int maxResults, int firstResult) {
        return findProizvodkorpaEntities(false, maxResults, firstResult);
    }

    private List<Proizvodkorpa> findProizvodkorpaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Proizvodkorpa.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Proizvodkorpa findProizvodkorpa(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Proizvodkorpa.class, id);
        } finally {
            em.close();
        }
    }

    public int getProizvodkorpaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Proizvodkorpa> rt = cq.from(Proizvodkorpa.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
