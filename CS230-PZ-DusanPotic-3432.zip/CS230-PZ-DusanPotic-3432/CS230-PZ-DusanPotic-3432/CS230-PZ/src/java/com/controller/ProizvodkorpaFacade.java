/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Proizvodkorpa;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Potic-Win10
 */
@Stateless
public class ProizvodkorpaFacade extends AbstractFacade<Proizvodkorpa> {

    @PersistenceContext(unitName = "CS230-PZPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProizvodkorpaFacade() {
        super(Proizvodkorpa.class);
    }
    
}
