/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.IllegalOrphanException;
import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import com.entity.Adresa;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Narudzbina;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class AdresaJpaController implements Serializable {

    public AdresaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Adresa adresa) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (adresa.getNarudzbinaList() == null) {
            adresa.setNarudzbinaList(new ArrayList<Narudzbina>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Narudzbina> attachedNarudzbinaList = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNarudzbinaToAttach : adresa.getNarudzbinaList()) {
                narudzbinaListNarudzbinaToAttach = em.getReference(narudzbinaListNarudzbinaToAttach.getClass(), narudzbinaListNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaList.add(narudzbinaListNarudzbinaToAttach);
            }
            adresa.setNarudzbinaList(attachedNarudzbinaList);
            em.persist(adresa);
            for (Narudzbina narudzbinaListNarudzbina : adresa.getNarudzbinaList()) {
                Adresa oldAdresaidOfNarudzbinaListNarudzbina = narudzbinaListNarudzbina.getAdresaid();
                narudzbinaListNarudzbina.setAdresaid(adresa);
                narudzbinaListNarudzbina = em.merge(narudzbinaListNarudzbina);
                if (oldAdresaidOfNarudzbinaListNarudzbina != null) {
                    oldAdresaidOfNarudzbinaListNarudzbina.getNarudzbinaList().remove(narudzbinaListNarudzbina);
                    oldAdresaidOfNarudzbinaListNarudzbina = em.merge(oldAdresaidOfNarudzbinaListNarudzbina);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findAdresa(adresa.getAdresaid()) != null) {
                throw new PreexistingEntityException("Adresa " + adresa + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Adresa adresa) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Adresa persistentAdresa = em.find(Adresa.class, adresa.getAdresaid());
            List<Narudzbina> narudzbinaListOld = persistentAdresa.getNarudzbinaList();
            List<Narudzbina> narudzbinaListNew = adresa.getNarudzbinaList();
            List<String> illegalOrphanMessages = null;
            for (Narudzbina narudzbinaListOldNarudzbina : narudzbinaListOld) {
                if (!narudzbinaListNew.contains(narudzbinaListOldNarudzbina)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Narudzbina " + narudzbinaListOldNarudzbina + " since its adresaid field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Narudzbina> attachedNarudzbinaListNew = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNewNarudzbinaToAttach : narudzbinaListNew) {
                narudzbinaListNewNarudzbinaToAttach = em.getReference(narudzbinaListNewNarudzbinaToAttach.getClass(), narudzbinaListNewNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaListNew.add(narudzbinaListNewNarudzbinaToAttach);
            }
            narudzbinaListNew = attachedNarudzbinaListNew;
            adresa.setNarudzbinaList(narudzbinaListNew);
            adresa = em.merge(adresa);
            for (Narudzbina narudzbinaListNewNarudzbina : narudzbinaListNew) {
                if (!narudzbinaListOld.contains(narudzbinaListNewNarudzbina)) {
                    Adresa oldAdresaidOfNarudzbinaListNewNarudzbina = narudzbinaListNewNarudzbina.getAdresaid();
                    narudzbinaListNewNarudzbina.setAdresaid(adresa);
                    narudzbinaListNewNarudzbina = em.merge(narudzbinaListNewNarudzbina);
                    if (oldAdresaidOfNarudzbinaListNewNarudzbina != null && !oldAdresaidOfNarudzbinaListNewNarudzbina.equals(adresa)) {
                        oldAdresaidOfNarudzbinaListNewNarudzbina.getNarudzbinaList().remove(narudzbinaListNewNarudzbina);
                        oldAdresaidOfNarudzbinaListNewNarudzbina = em.merge(oldAdresaidOfNarudzbinaListNewNarudzbina);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = adresa.getAdresaid();
                if (findAdresa(id) == null) {
                    throw new NonexistentEntityException("The adresa with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Adresa adresa;
            try {
                adresa = em.getReference(Adresa.class, id);
                adresa.getAdresaid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The adresa with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Narudzbina> narudzbinaListOrphanCheck = adresa.getNarudzbinaList();
            for (Narudzbina narudzbinaListOrphanCheckNarudzbina : narudzbinaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Adresa (" + adresa + ") cannot be destroyed since the Narudzbina " + narudzbinaListOrphanCheckNarudzbina + " in its narudzbinaList field has a non-nullable adresaid field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(adresa);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Adresa> findAdresaEntities() {
        return findAdresaEntities(true, -1, -1);
    }

    public List<Adresa> findAdresaEntities(int maxResults, int firstResult) {
        return findAdresaEntities(false, maxResults, firstResult);
    }

    private List<Adresa> findAdresaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Adresa.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Adresa findAdresa(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Adresa.class, id);
        } finally {
            em.close();
        }
    }

    public int getAdresaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Adresa> rt = cq.from(Adresa.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
