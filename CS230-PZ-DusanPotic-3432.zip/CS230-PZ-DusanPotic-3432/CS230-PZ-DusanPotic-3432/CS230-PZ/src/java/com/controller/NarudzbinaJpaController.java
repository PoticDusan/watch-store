/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Adresa;
import com.entity.Korisnik;
import com.entity.Korpa;
import com.entity.Narudzbina;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class NarudzbinaJpaController implements Serializable {

    public NarudzbinaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Narudzbina narudzbina) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Adresa adresaid = narudzbina.getAdresaid();
            if (adresaid != null) {
                adresaid = em.getReference(adresaid.getClass(), adresaid.getAdresaid());
                narudzbina.setAdresaid(adresaid);
            }
            Korisnik korisnikid = narudzbina.getKorisnikid();
            if (korisnikid != null) {
                korisnikid = em.getReference(korisnikid.getClass(), korisnikid.getKorisnikid());
                narudzbina.setKorisnikid(korisnikid);
            }
            Korpa korpaid = narudzbina.getKorpaid();
            if (korpaid != null) {
                korpaid = em.getReference(korpaid.getClass(), korpaid.getKorpaid());
                narudzbina.setKorpaid(korpaid);
            }
            em.persist(narudzbina);
            if (adresaid != null) {
                adresaid.getNarudzbinaList().add(narudzbina);
                adresaid = em.merge(adresaid);
            }
            if (korisnikid != null) {
                korisnikid.getNarudzbinaList().add(narudzbina);
                korisnikid = em.merge(korisnikid);
            }
            if (korpaid != null) {
                korpaid.getNarudzbinaList().add(narudzbina);
                korpaid = em.merge(korpaid);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findNarudzbina(narudzbina.getNarudzbinaid()) != null) {
                throw new PreexistingEntityException("Narudzbina " + narudzbina + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Narudzbina narudzbina) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Narudzbina persistentNarudzbina = em.find(Narudzbina.class, narudzbina.getNarudzbinaid());
            Adresa adresaidOld = persistentNarudzbina.getAdresaid();
            Adresa adresaidNew = narudzbina.getAdresaid();
            Korisnik korisnikidOld = persistentNarudzbina.getKorisnikid();
            Korisnik korisnikidNew = narudzbina.getKorisnikid();
            Korpa korpaidOld = persistentNarudzbina.getKorpaid();
            Korpa korpaidNew = narudzbina.getKorpaid();
            if (adresaidNew != null) {
                adresaidNew = em.getReference(adresaidNew.getClass(), adresaidNew.getAdresaid());
                narudzbina.setAdresaid(adresaidNew);
            }
            if (korisnikidNew != null) {
                korisnikidNew = em.getReference(korisnikidNew.getClass(), korisnikidNew.getKorisnikid());
                narudzbina.setKorisnikid(korisnikidNew);
            }
            if (korpaidNew != null) {
                korpaidNew = em.getReference(korpaidNew.getClass(), korpaidNew.getKorpaid());
                narudzbina.setKorpaid(korpaidNew);
            }
            narudzbina = em.merge(narudzbina);
            if (adresaidOld != null && !adresaidOld.equals(adresaidNew)) {
                adresaidOld.getNarudzbinaList().remove(narudzbina);
                adresaidOld = em.merge(adresaidOld);
            }
            if (adresaidNew != null && !adresaidNew.equals(adresaidOld)) {
                adresaidNew.getNarudzbinaList().add(narudzbina);
                adresaidNew = em.merge(adresaidNew);
            }
            if (korisnikidOld != null && !korisnikidOld.equals(korisnikidNew)) {
                korisnikidOld.getNarudzbinaList().remove(narudzbina);
                korisnikidOld = em.merge(korisnikidOld);
            }
            if (korisnikidNew != null && !korisnikidNew.equals(korisnikidOld)) {
                korisnikidNew.getNarudzbinaList().add(narudzbina);
                korisnikidNew = em.merge(korisnikidNew);
            }
            if (korpaidOld != null && !korpaidOld.equals(korpaidNew)) {
                korpaidOld.getNarudzbinaList().remove(narudzbina);
                korpaidOld = em.merge(korpaidOld);
            }
            if (korpaidNew != null && !korpaidNew.equals(korpaidOld)) {
                korpaidNew.getNarudzbinaList().add(narudzbina);
                korpaidNew = em.merge(korpaidNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = narudzbina.getNarudzbinaid();
                if (findNarudzbina(id) == null) {
                    throw new NonexistentEntityException("The narudzbina with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Narudzbina narudzbina;
            try {
                narudzbina = em.getReference(Narudzbina.class, id);
                narudzbina.getNarudzbinaid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The narudzbina with id " + id + " no longer exists.", enfe);
            }
            Adresa adresaid = narudzbina.getAdresaid();
            if (adresaid != null) {
                adresaid.getNarudzbinaList().remove(narudzbina);
                adresaid = em.merge(adresaid);
            }
            Korisnik korisnikid = narudzbina.getKorisnikid();
            if (korisnikid != null) {
                korisnikid.getNarudzbinaList().remove(narudzbina);
                korisnikid = em.merge(korisnikid);
            }
            Korpa korpaid = narudzbina.getKorpaid();
            if (korpaid != null) {
                korpaid.getNarudzbinaList().remove(narudzbina);
                korpaid = em.merge(korpaid);
            }
            em.remove(narudzbina);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Narudzbina> findNarudzbinaEntities() {
        return findNarudzbinaEntities(true, -1, -1);
    }

    public List<Narudzbina> findNarudzbinaEntities(int maxResults, int firstResult) {
        return findNarudzbinaEntities(false, maxResults, firstResult);
    }

    private List<Narudzbina> findNarudzbinaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Narudzbina.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Narudzbina findNarudzbina(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Narudzbina.class, id);
        } finally {
            em.close();
        }
    }

    public int getNarudzbinaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Narudzbina> rt = cq.from(Narudzbina.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
