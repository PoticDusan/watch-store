/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.IllegalOrphanException;
import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import com.entity.Korisnik;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Narudzbina;
import java.util.ArrayList;
import java.util.List;
import com.entity.Korpa;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class KorisnikJpaController implements Serializable {

    public KorisnikJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Korisnik korisnik) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (korisnik.getNarudzbinaList() == null) {
            korisnik.setNarudzbinaList(new ArrayList<Narudzbina>());
        }
        if (korisnik.getKorpaList() == null) {
            korisnik.setKorpaList(new ArrayList<Korpa>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Narudzbina> attachedNarudzbinaList = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNarudzbinaToAttach : korisnik.getNarudzbinaList()) {
                narudzbinaListNarudzbinaToAttach = em.getReference(narudzbinaListNarudzbinaToAttach.getClass(), narudzbinaListNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaList.add(narudzbinaListNarudzbinaToAttach);
            }
            korisnik.setNarudzbinaList(attachedNarudzbinaList);
            List<Korpa> attachedKorpaList = new ArrayList<Korpa>();
            for (Korpa korpaListKorpaToAttach : korisnik.getKorpaList()) {
                korpaListKorpaToAttach = em.getReference(korpaListKorpaToAttach.getClass(), korpaListKorpaToAttach.getKorpaid());
                attachedKorpaList.add(korpaListKorpaToAttach);
            }
            korisnik.setKorpaList(attachedKorpaList);
            em.persist(korisnik);
            for (Narudzbina narudzbinaListNarudzbina : korisnik.getNarudzbinaList()) {
                Korisnik oldKorisnikidOfNarudzbinaListNarudzbina = narudzbinaListNarudzbina.getKorisnikid();
                narudzbinaListNarudzbina.setKorisnikid(korisnik);
                narudzbinaListNarudzbina = em.merge(narudzbinaListNarudzbina);
                if (oldKorisnikidOfNarudzbinaListNarudzbina != null) {
                    oldKorisnikidOfNarudzbinaListNarudzbina.getNarudzbinaList().remove(narudzbinaListNarudzbina);
                    oldKorisnikidOfNarudzbinaListNarudzbina = em.merge(oldKorisnikidOfNarudzbinaListNarudzbina);
                }
            }
            for (Korpa korpaListKorpa : korisnik.getKorpaList()) {
                Korisnik oldKorisnikidOfKorpaListKorpa = korpaListKorpa.getKorisnikid();
                korpaListKorpa.setKorisnikid(korisnik);
                korpaListKorpa = em.merge(korpaListKorpa);
                if (oldKorisnikidOfKorpaListKorpa != null) {
                    oldKorisnikidOfKorpaListKorpa.getKorpaList().remove(korpaListKorpa);
                    oldKorisnikidOfKorpaListKorpa = em.merge(oldKorisnikidOfKorpaListKorpa);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findKorisnik(korisnik.getKorisnikid()) != null) {
                throw new PreexistingEntityException("Korisnik " + korisnik + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Korisnik korisnik) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik persistentKorisnik = em.find(Korisnik.class, korisnik.getKorisnikid());
            List<Narudzbina> narudzbinaListOld = persistentKorisnik.getNarudzbinaList();
            List<Narudzbina> narudzbinaListNew = korisnik.getNarudzbinaList();
            List<Korpa> korpaListOld = persistentKorisnik.getKorpaList();
            List<Korpa> korpaListNew = korisnik.getKorpaList();
            List<String> illegalOrphanMessages = null;
            for (Narudzbina narudzbinaListOldNarudzbina : narudzbinaListOld) {
                if (!narudzbinaListNew.contains(narudzbinaListOldNarudzbina)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Narudzbina " + narudzbinaListOldNarudzbina + " since its korisnikid field is not nullable.");
                }
            }
            for (Korpa korpaListOldKorpa : korpaListOld) {
                if (!korpaListNew.contains(korpaListOldKorpa)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Korpa " + korpaListOldKorpa + " since its korisnikid field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Narudzbina> attachedNarudzbinaListNew = new ArrayList<Narudzbina>();
            for (Narudzbina narudzbinaListNewNarudzbinaToAttach : narudzbinaListNew) {
                narudzbinaListNewNarudzbinaToAttach = em.getReference(narudzbinaListNewNarudzbinaToAttach.getClass(), narudzbinaListNewNarudzbinaToAttach.getNarudzbinaid());
                attachedNarudzbinaListNew.add(narudzbinaListNewNarudzbinaToAttach);
            }
            narudzbinaListNew = attachedNarudzbinaListNew;
            korisnik.setNarudzbinaList(narudzbinaListNew);
            List<Korpa> attachedKorpaListNew = new ArrayList<Korpa>();
            for (Korpa korpaListNewKorpaToAttach : korpaListNew) {
                korpaListNewKorpaToAttach = em.getReference(korpaListNewKorpaToAttach.getClass(), korpaListNewKorpaToAttach.getKorpaid());
                attachedKorpaListNew.add(korpaListNewKorpaToAttach);
            }
            korpaListNew = attachedKorpaListNew;
            korisnik.setKorpaList(korpaListNew);
            korisnik = em.merge(korisnik);
            for (Narudzbina narudzbinaListNewNarudzbina : narudzbinaListNew) {
                if (!narudzbinaListOld.contains(narudzbinaListNewNarudzbina)) {
                    Korisnik oldKorisnikidOfNarudzbinaListNewNarudzbina = narudzbinaListNewNarudzbina.getKorisnikid();
                    narudzbinaListNewNarudzbina.setKorisnikid(korisnik);
                    narudzbinaListNewNarudzbina = em.merge(narudzbinaListNewNarudzbina);
                    if (oldKorisnikidOfNarudzbinaListNewNarudzbina != null && !oldKorisnikidOfNarudzbinaListNewNarudzbina.equals(korisnik)) {
                        oldKorisnikidOfNarudzbinaListNewNarudzbina.getNarudzbinaList().remove(narudzbinaListNewNarudzbina);
                        oldKorisnikidOfNarudzbinaListNewNarudzbina = em.merge(oldKorisnikidOfNarudzbinaListNewNarudzbina);
                    }
                }
            }
            for (Korpa korpaListNewKorpa : korpaListNew) {
                if (!korpaListOld.contains(korpaListNewKorpa)) {
                    Korisnik oldKorisnikidOfKorpaListNewKorpa = korpaListNewKorpa.getKorisnikid();
                    korpaListNewKorpa.setKorisnikid(korisnik);
                    korpaListNewKorpa = em.merge(korpaListNewKorpa);
                    if (oldKorisnikidOfKorpaListNewKorpa != null && !oldKorisnikidOfKorpaListNewKorpa.equals(korisnik)) {
                        oldKorisnikidOfKorpaListNewKorpa.getKorpaList().remove(korpaListNewKorpa);
                        oldKorisnikidOfKorpaListNewKorpa = em.merge(oldKorisnikidOfKorpaListNewKorpa);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = korisnik.getKorisnikid();
                if (findKorisnik(id) == null) {
                    throw new NonexistentEntityException("The korisnik with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Korisnik korisnik;
            try {
                korisnik = em.getReference(Korisnik.class, id);
                korisnik.getKorisnikid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The korisnik with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Narudzbina> narudzbinaListOrphanCheck = korisnik.getNarudzbinaList();
            for (Narudzbina narudzbinaListOrphanCheckNarudzbina : narudzbinaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korisnik (" + korisnik + ") cannot be destroyed since the Narudzbina " + narudzbinaListOrphanCheckNarudzbina + " in its narudzbinaList field has a non-nullable korisnikid field.");
            }
            List<Korpa> korpaListOrphanCheck = korisnik.getKorpaList();
            for (Korpa korpaListOrphanCheckKorpa : korpaListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Korisnik (" + korisnik + ") cannot be destroyed since the Korpa " + korpaListOrphanCheckKorpa + " in its korpaList field has a non-nullable korisnikid field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(korisnik);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Korisnik> findKorisnikEntities() {
        return findKorisnikEntities(true, -1, -1);
    }

    public List<Korisnik> findKorisnikEntities(int maxResults, int firstResult) {
        return findKorisnikEntities(false, maxResults, firstResult);
    }

    private List<Korisnik> findKorisnikEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Korisnik.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Korisnik findKorisnik(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Korisnik.class, id);
        } finally {
            em.close();
        }
    }

    public int getKorisnikCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Korisnik> rt = cq.from(Korisnik.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
