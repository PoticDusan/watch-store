/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.controller.exceptions.IllegalOrphanException;
import com.controller.exceptions.NonexistentEntityException;
import com.controller.exceptions.PreexistingEntityException;
import com.controller.exceptions.RollbackFailureException;
import com.entity.Kategorija;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.entity.Proizvod;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.transaction.UserTransaction;

/**
 *
 * @author Potic-Win10
 */
public class KategorijaJpaController implements Serializable {

    public KategorijaJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Kategorija kategorija) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (kategorija.getProizvodList() == null) {
            kategorija.setProizvodList(new ArrayList<Proizvod>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Proizvod> attachedProizvodList = new ArrayList<Proizvod>();
            for (Proizvod proizvodListProizvodToAttach : kategorija.getProizvodList()) {
                proizvodListProizvodToAttach = em.getReference(proizvodListProizvodToAttach.getClass(), proizvodListProizvodToAttach.getProizvodid());
                attachedProizvodList.add(proizvodListProizvodToAttach);
            }
            kategorija.setProizvodList(attachedProizvodList);
            em.persist(kategorija);
            for (Proizvod proizvodListProizvod : kategorija.getProizvodList()) {
                Kategorija oldKategorijaidOfProizvodListProizvod = proizvodListProizvod.getKategorijaid();
                proizvodListProizvod.setKategorijaid(kategorija);
                proizvodListProizvod = em.merge(proizvodListProizvod);
                if (oldKategorijaidOfProizvodListProizvod != null) {
                    oldKategorijaidOfProizvodListProizvod.getProizvodList().remove(proizvodListProizvod);
                    oldKategorijaidOfProizvodListProizvod = em.merge(oldKategorijaidOfProizvodListProizvod);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findKategorija(kategorija.getKategorijaid()) != null) {
                throw new PreexistingEntityException("Kategorija " + kategorija + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Kategorija kategorija) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija persistentKategorija = em.find(Kategorija.class, kategorija.getKategorijaid());
            List<Proizvod> proizvodListOld = persistentKategorija.getProizvodList();
            List<Proizvod> proizvodListNew = kategorija.getProizvodList();
            List<String> illegalOrphanMessages = null;
            for (Proizvod proizvodListOldProizvod : proizvodListOld) {
                if (!proizvodListNew.contains(proizvodListOldProizvod)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Proizvod " + proizvodListOldProizvod + " since its kategorijaid field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Proizvod> attachedProizvodListNew = new ArrayList<Proizvod>();
            for (Proizvod proizvodListNewProizvodToAttach : proizvodListNew) {
                proizvodListNewProizvodToAttach = em.getReference(proizvodListNewProizvodToAttach.getClass(), proizvodListNewProizvodToAttach.getProizvodid());
                attachedProizvodListNew.add(proizvodListNewProizvodToAttach);
            }
            proizvodListNew = attachedProizvodListNew;
            kategorija.setProizvodList(proizvodListNew);
            kategorija = em.merge(kategorija);
            for (Proizvod proizvodListNewProizvod : proizvodListNew) {
                if (!proizvodListOld.contains(proizvodListNewProizvod)) {
                    Kategorija oldKategorijaidOfProizvodListNewProizvod = proizvodListNewProizvod.getKategorijaid();
                    proizvodListNewProizvod.setKategorijaid(kategorija);
                    proizvodListNewProizvod = em.merge(proizvodListNewProizvod);
                    if (oldKategorijaidOfProizvodListNewProizvod != null && !oldKategorijaidOfProizvodListNewProizvod.equals(kategorija)) {
                        oldKategorijaidOfProizvodListNewProizvod.getProizvodList().remove(proizvodListNewProizvod);
                        oldKategorijaidOfProizvodListNewProizvod = em.merge(oldKategorijaidOfProizvodListNewProizvod);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = kategorija.getKategorijaid();
                if (findKategorija(id) == null) {
                    throw new NonexistentEntityException("The kategorija with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Kategorija kategorija;
            try {
                kategorija = em.getReference(Kategorija.class, id);
                kategorija.getKategorijaid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The kategorija with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Proizvod> proizvodListOrphanCheck = kategorija.getProizvodList();
            for (Proizvod proizvodListOrphanCheckProizvod : proizvodListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Kategorija (" + kategorija + ") cannot be destroyed since the Proizvod " + proizvodListOrphanCheckProizvod + " in its proizvodList field has a non-nullable kategorijaid field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(kategorija);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Kategorija> findKategorijaEntities() {
        return findKategorijaEntities(true, -1, -1);
    }

    public List<Kategorija> findKategorijaEntities(int maxResults, int firstResult) {
        return findKategorijaEntities(false, maxResults, firstResult);
    }

    private List<Kategorija> findKategorijaEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Kategorija.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Kategorija findKategorija(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Kategorija.class, id);
        } finally {
            em.close();
        }
    }

    public int getKategorijaCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Kategorija> rt = cq.from(Kategorija.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
