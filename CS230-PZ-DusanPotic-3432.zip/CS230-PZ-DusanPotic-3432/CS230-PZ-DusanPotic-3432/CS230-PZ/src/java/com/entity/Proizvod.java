/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "proizvod")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Proizvod.findAll", query = "SELECT p FROM Proizvod p")
    , @NamedQuery(name = "Proizvod.findByProizvodid", query = "SELECT p FROM Proizvod p WHERE p.proizvodid = :proizvodid")
    , @NamedQuery(name = "Proizvod.findBySlika", query = "SELECT p FROM Proizvod p WHERE p.slika = :slika")
    , @NamedQuery(name = "Proizvod.findByTip", query = "SELECT p FROM Proizvod p WHERE p.tip = :tip")
    , @NamedQuery(name = "Proizvod.findByNaziv", query = "SELECT p FROM Proizvod p WHERE p.naziv = :naziv")
    , @NamedQuery(name = "Proizvod.findByOpis", query = "SELECT p FROM Proizvod p WHERE p.opis = :opis")
    , @NamedQuery(name = "Proizvod.findByCena", query = "SELECT p FROM Proizvod p WHERE p.cena = :cena")
    , @NamedQuery(name = "Proizvod.findByKolicina", query = "SELECT p FROM Proizvod p WHERE p.kolicina = :kolicina")
    , @NamedQuery(name = "Proizvod.findByStatus", query = "SELECT p FROM Proizvod p WHERE p.status = :status")
    , @NamedQuery(name = "Proizvod.findAllAvailable", query = "SELECT p FROM Proizvod p WHERE p.status = 1")
})

public class Proizvod implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "PROIZVODID")
    private Integer proizvodid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "SLIKA")
    private String slika;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "TIP")
    private String tip;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "NAZIV")
    private String naziv;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "OPIS")
    private String opis;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CENA")
    private float cena;
    @Basic(optional = false)
    @NotNull
    @Column(name = "KOLICINA")
    private int kolicina;
    @Basic(optional = false)
    @NotNull
    @Column(name = "STATUS")
    private short status;
    @JoinColumn(name = "KATEGORIJAID", referencedColumnName = "KATEGORIJAID")
    @ManyToOne(optional = false)
    private Kategorija kategorijaid;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "proizvodid")
    private List<Proizvodkorpa> proizvodkorpaList;

    public Proizvod() {
    }

    public Proizvod(Integer proizvodid) {
        this.proizvodid = proizvodid;
    }

    public Proizvod(Integer proizvodid, String slika, String tip, String naziv, String opis, float cena, int kolicina, short status) {
        this.proizvodid = proizvodid;
        this.slika = slika;
        this.tip = tip;
        this.naziv = naziv;
        this.opis = opis;
        this.cena = cena;
        this.kolicina = kolicina;
        this.status = status;
    }

    public Integer getProizvodid() {
        return proizvodid;
    }

    public void setProizvodid(Integer proizvodid) {
        this.proizvodid = proizvodid;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public float getCena() {
        return cena;
    }

    public void setCena(float cena) {
        this.cena = cena;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public Kategorija getKategorijaid() {
        return kategorijaid;
    }

    public void setKategorijaid(Kategorija kategorijaid) {
        this.kategorijaid = kategorijaid;
    }

    @XmlTransient
    public List<Proizvodkorpa> getProizvodkorpaList() {
        return proizvodkorpaList;
    }

    public void setProizvodkorpaList(List<Proizvodkorpa> proizvodkorpaList) {
        this.proizvodkorpaList = proizvodkorpaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (proizvodid != null ? proizvodid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Proizvod)) {
            return false;
        }
        Proizvod other = (Proizvod) object;
        if ((this.proizvodid == null && other.proizvodid != null) || (this.proizvodid != null && !this.proizvodid.equals(other.proizvodid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Proizvod[ proizvodid=" + proizvodid + " ]";
    }

}
