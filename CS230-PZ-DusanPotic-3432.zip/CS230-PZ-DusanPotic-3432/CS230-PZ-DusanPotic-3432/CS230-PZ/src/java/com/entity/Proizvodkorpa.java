/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "proizvodkorpa")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Proizvodkorpa.findAll", query = "SELECT p FROM Proizvodkorpa p")
    ,@NamedQuery(name = "Proizvodkorpa.findNextID", query = "SELECT MAX(p.proizvodkorpaid)+1 FROM Proizvodkorpa p")
    ,@NamedQuery(name = "Proizvodkorpa.findByKorpaID", query = "SELECT p FROM Proizvodkorpa p WHERE p.korpaid = :korpaid")
    , @NamedQuery(name = "Proizvodkorpa.findByProizvodkorpaid", query = "SELECT p FROM Proizvodkorpa p WHERE p.proizvodkorpaid = :proizvodkorpaid")
    , @NamedQuery(name = "Proizvodkorpa.findByKolicina", query = "SELECT p FROM Proizvodkorpa p WHERE p.kolicina = :kolicina")})
public class Proizvodkorpa implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "PROIZVODKORPAID")
    private Integer proizvodkorpaid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "KOLICINA")
    private int kolicina;
    @JoinColumn(name = "KORPAID", referencedColumnName = "KORPAID")
    @ManyToOne(optional = false)
    private Korpa korpaid;
    @JoinColumn(name = "PROIZVODID", referencedColumnName = "PROIZVODID")
    @ManyToOne(optional = false)
    private Proizvod proizvodid;

    public Proizvodkorpa() {
    }

    public Proizvodkorpa(Integer proizvodkorpaid) {
        this.proizvodkorpaid = proizvodkorpaid;
    }

    public Proizvodkorpa(Integer proizvodkorpaid, int kolicina) {
        this.proizvodkorpaid = proizvodkorpaid;
        this.kolicina = kolicina;
    }

    public Integer getProizvodkorpaid() {
        return proizvodkorpaid;
    }

    public void setProizvodkorpaid(Integer proizvodkorpaid) {
        this.proizvodkorpaid = proizvodkorpaid;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public Korpa getKorpaid() {
        return korpaid;
    }

    public void setKorpaid(Korpa korpaid) {
        this.korpaid = korpaid;
    }

    public Proizvod getProizvodid() {
        return proizvodid;
    }

    public void setProizvodid(Proizvod proizvodid) {
        this.proizvodid = proizvodid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (proizvodkorpaid != null ? proizvodkorpaid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Proizvodkorpa)) {
            return false;
        }
        Proizvodkorpa other = (Proizvodkorpa) object;
        if ((this.proizvodkorpaid == null && other.proizvodkorpaid != null) || (this.proizvodkorpaid != null && !this.proizvodkorpaid.equals(other.proizvodkorpaid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Proizvodkorpa[ proizvodkorpaid=" + proizvodkorpaid + " ]";
    }

}
