/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "narudzbina")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Narudzbina.findAll", query = "SELECT n FROM Narudzbina n")
    ,@NamedQuery(name = "Narudzbina.findNextId", query = "SELECT MAX(n.narudzbinaid)+1 FROM Narudzbina n")
    , @NamedQuery(name = "Narudzbina.findByNarudzbinaid", query = "SELECT n FROM Narudzbina n WHERE n.narudzbinaid = :narudzbinaid")
    , @NamedQuery(name = "Narudzbina.findByDatum", query = "SELECT n FROM Narudzbina n WHERE n.datum = :datum")
    , @NamedQuery(name = "Narudzbina.findBySuma", query = "SELECT n FROM Narudzbina n WHERE n.suma = :suma")
    , @NamedQuery(name = "Narudzbina.findByStatus", query = "SELECT n FROM Narudzbina n WHERE n.status = :status")})
public class Narudzbina implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "NARUDZBINAID")
    private Integer narudzbinaid;

    @Basic(optional = false)
    @NotNull
    @Column(name = "RACUN")
    private String racun;

    @Basic(optional = false)
    @NotNull
    @Column(name = "DATUM")
    private String datum;

    @Basic(optional = false)
    @NotNull
    @Column(name = "SUMA")
    private float suma;

    @Basic(optional = false)
    @NotNull
    @Column(name = "STATUS")
    private short status;

    @JoinColumn(name = "ADRESAID", referencedColumnName = "ADRESAID")
    @ManyToOne(optional = false)
    private Adresa adresaid;

    @JoinColumn(name = "KORISNIKID", referencedColumnName = "KORISNIKID")
    @ManyToOne(optional = false)
    private Korisnik korisnikid;

    @JoinColumn(name = "KORPAID", referencedColumnName = "KORPAID")
    @ManyToOne(optional = false)
    private Korpa korpaid;

    public Narudzbina() {
    }

    public Narudzbina(Integer narudzbinaid) {
        this.narudzbinaid = narudzbinaid;
    }

    public Narudzbina(Integer narudzbinaid, String racun, String datum, float suma, short status) {
        this.narudzbinaid = narudzbinaid;
        this.racun = racun;
        this.datum = datum;
        this.suma = suma;
        this.status = status;
    }

    public Integer getNarudzbinaid() {
        return narudzbinaid;
    }

    public void setNarudzbinaid(Integer narudzbinaid) {
        this.narudzbinaid = narudzbinaid;
    }

    public String getRacun() {
        return racun;
    }

    public void setRacun(String racun) {
        this.racun = racun;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public float getSuma() {
        return suma;
    }

    public void setSuma(float suma) {
        this.suma = suma;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public Adresa getAdresaid() {
        return adresaid;
    }

    public void setAdresaid(Adresa adresaid) {
        this.adresaid = adresaid;
    }

    public Korisnik getKorisnikid() {
        return korisnikid;
    }

    public void setKorisnikid(Korisnik korisnikid) {
        this.korisnikid = korisnikid;
    }

    public Korpa getKorpaid() {
        return korpaid;
    }

    public void setKorpaid(Korpa korpaid) {
        this.korpaid = korpaid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (narudzbinaid != null ? narudzbinaid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Narudzbina)) {
            return false;
        }
        Narudzbina other = (Narudzbina) object;
        if ((this.narudzbinaid == null && other.narudzbinaid != null) || (this.narudzbinaid != null && !this.narudzbinaid.equals(other.narudzbinaid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Narudzbina[ narudzbinaid=" + narudzbinaid + " ]";
    }

    public void setStatus(int i) {
        this.status= (short) i;
    }

}
