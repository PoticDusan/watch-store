/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "kategorija")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Kategorija.findAll", query = "SELECT k FROM Kategorija k")
    , @NamedQuery(name = "Kategorija.findByKategorijaid", query = "SELECT k FROM Kategorija k WHERE k.kategorijaid = :kategorijaid")
    , @NamedQuery(name = "Kategorija.findByTip", query = "SELECT k FROM Kategorija k WHERE k.tip = :tip")})
public class Kategorija implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "KATEGORIJAID")
    private Integer kategorijaid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "TIP")
    private String tip;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "kategorijaid")
    private List<Proizvod> proizvodList;

    public Kategorija() {
    }

    public Kategorija(Integer kategorijaid) {
        this.kategorijaid = kategorijaid;
    }

    public Kategorija(Integer kategorijaid, String tip) {
        this.kategorijaid = kategorijaid;
        this.tip = tip;
    }

    public Integer getKategorijaid() {
        return kategorijaid;
    }

    public void setKategorijaid(Integer kategorijaid) {
        this.kategorijaid = kategorijaid;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    @XmlTransient
    public List<Proizvod> getProizvodList() {
        return proizvodList;
    }

    public void setProizvodList(List<Proizvod> proizvodList) {
        this.proizvodList = proizvodList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (kategorijaid != null ? kategorijaid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Kategorija)) {
            return false;
        }
        Kategorija other = (Kategorija) object;
        if ((this.kategorijaid == null && other.kategorijaid != null) || (this.kategorijaid != null && !this.kategorijaid.equals(other.kategorijaid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Kategorija[ kategorijaid=" + kategorijaid + " ]";
    }
    
}
