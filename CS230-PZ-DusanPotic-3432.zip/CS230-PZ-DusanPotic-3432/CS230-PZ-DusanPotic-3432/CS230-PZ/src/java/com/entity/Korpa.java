/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "korpa")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Korpa.findAll", query = "SELECT k FROM Korpa k")
    ,@NamedQuery(name = "Korpa.findNextId", query = "SELECT MAX(k.korpaid)+1 FROM Korpa k")
    , @NamedQuery(name = "Korpa.findByKorisnikId", query = "SELECT k FROM Korpa k WHERE k.korisnikid = :korisnikid")
    , @NamedQuery(name = "Korpa.findByKorpaid", query = "SELECT k FROM Korpa k WHERE k.korpaid = :korpaid")
})
public class Korpa implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "KORPAID")
    private Integer korpaid;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "korpaid")
    private List<Narudzbina> narudzbinaList;

    @JoinColumn(name = "KORISNIKID", referencedColumnName = "KORISNIKID")
    @ManyToOne(optional = false)
    private Korisnik korisnikid;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "korpaid")
    private List<Proizvodkorpa> proizvodkorpaList;

    public Korpa() {
    }

    public Korpa(Integer korpaid) {
        this.korpaid = korpaid;
    }

    public Integer getKorpaid() {
        return korpaid;
    }

    public void setKorpaid(Integer korpaid) {
        this.korpaid = korpaid;
    }

    @XmlTransient
    public List<Narudzbina> getNarudzbinaList() {
        return narudzbinaList;
    }

    public void setNarudzbinaList(List<Narudzbina> narudzbinaList) {
        this.narudzbinaList = narudzbinaList;
    }

    public Korisnik getKorisnikid() {
        return korisnikid;
    }

    public void setKorisnikid(Korisnik korisnikid) {
        this.korisnikid = korisnikid;
    }

    @XmlTransient
    public List<Proizvodkorpa> getProizvodkorpaList() {
        return proizvodkorpaList;
    }

    public void setProizvodkorpaList(List<Proizvodkorpa> proizvodkorpaList) {
        this.proizvodkorpaList = proizvodkorpaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (korpaid != null ? korpaid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Korpa)) {
            return false;
        }
        Korpa other = (Korpa) object;
        if ((this.korpaid == null && other.korpaid != null) || (this.korpaid != null && !this.korpaid.equals(other.korpaid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Korpa[ korpaid=" + korpaid + " ]";
    }

}
