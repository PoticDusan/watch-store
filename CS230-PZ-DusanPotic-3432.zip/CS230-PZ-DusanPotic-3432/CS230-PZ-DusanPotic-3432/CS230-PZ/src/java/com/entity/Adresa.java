/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Potic-Win10
 */
@Entity
@Table(name = "adresa")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Adresa.findAll", query = "SELECT a FROM Adresa a")
    ,@NamedQuery(name = "Adresa.findNextId", query = "SELECT MAX(a.adresaid)+1 FROM Adresa a")
    , @NamedQuery(name = "Adresa.findByAdresaid", query = "SELECT a FROM Adresa a WHERE a.adresaid = :adresaid")
    , @NamedQuery(name = "Adresa.findByDrzava", query = "SELECT a FROM Adresa a WHERE a.drzava = :drzava")
    , @NamedQuery(name = "Adresa.findByGrad", query = "SELECT a FROM Adresa a WHERE a.grad = :grad")
    , @NamedQuery(name = "Adresa.findByUlica", query = "SELECT a FROM Adresa a WHERE a.ulica = :ulica")
    , @NamedQuery(name = "Adresa.findByBroj", query = "SELECT a FROM Adresa a WHERE a.broj = :broj")})
public class Adresa implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ADRESAID")
    private Integer adresaid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "DRZAVA")
    private String drzava;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "GRAD")
    private String grad;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "ULICA")
    private String ulica;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "BROJ")
    private String broj;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "adresaid")
    private List<Narudzbina> narudzbinaList;

    public Adresa() {
    }

    public Adresa(Integer adresaid) {
        this.adresaid = adresaid;
    }

    public Adresa(Integer adresaid, String drzava, String grad, String ulica, String broj) {
        this.adresaid = adresaid;
        this.drzava = drzava;
        this.grad = grad;
        this.ulica = ulica;
        this.broj = broj;
    }

    public Integer getAdresaid() {
        return adresaid;
    }

    public void setAdresaid(Integer adresaid) {
        this.adresaid = adresaid;
    }

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public String getBroj() {
        return broj;
    }

    public void setBroj(String broj) {
        this.broj = broj;
    }

    @XmlTransient
    public List<Narudzbina> getNarudzbinaList() {
        return narudzbinaList;
    }

    public void setNarudzbinaList(List<Narudzbina> narudzbinaList) {
        this.narudzbinaList = narudzbinaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (adresaid != null ? adresaid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Adresa)) {
            return false;
        }
        Adresa other = (Adresa) object;
        if ((this.adresaid == null && other.adresaid != null) || (this.adresaid != null && !this.adresaid.equals(other.adresaid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entity.Adresa[ adresaid=" + adresaid + " ]";
    }

}
