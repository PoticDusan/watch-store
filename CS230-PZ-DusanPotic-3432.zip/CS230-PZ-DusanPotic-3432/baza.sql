/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 12                       */
/* Created on:     6/26/2019 7:56:57 PM                         */
/*==============================================================*/




drop table if exists ADRESA;

drop table if exists KATEGORIJA;

drop table if exists KORISNIK;

drop table if exists KORPA;

drop table if exists NARUDZBINA;

drop table if exists PROIZVOD;

drop table if exists PROIZVODKORPA;

/*==============================================================*/
/* Table: ADRESA                                                */
/*==============================================================*/
create table ADRESA 
(
   ADRESAID             integer                        not null,
   DRZAVA               varchar(20)                    not null,
   GRAD                 varchar(20)                    not null,
   ULICA                varchar(30)                    not null,
   BROJ                 varchar(5)                     not null,
   constraint PK_ADRESA primary key (ADRESAID)
);

/*==============================================================*/
/* Index: ADRESA_PK                                             */
/*==============================================================*/
create unique index ADRESA_PK on ADRESA (
ADRESAID ASC
);

/*==============================================================*/
/* Table: KATEGORIJA                                            */
/*==============================================================*/
create table KATEGORIJA 
(
   KATEGORIJAID         integer                        not null,
   TIP                  varchar(20)                    not null,
   constraint PK_KATEGORIJA primary key (KATEGORIJAID)
);

/*==============================================================*/
/* Index: KATEGORIJA_PK                                         */
/*==============================================================*/
create unique index KATEGORIJA_PK on KATEGORIJA (
KATEGORIJAID ASC
);

/*==============================================================*/
/* Table: KORISNIK                                              */
/*==============================================================*/
create table KORISNIK 
(
   KORISNIKID           integer                        not null,
   IME                  varchar(20)                    not null,
   PREZIME              varchar(20)                    not null,
   EMAIL                varchar(40)                    not null,
   PASSWORD             varchar(20)                    not null,
   ROLE                 varchar(10)                    not null,
   constraint PK_KORISNIK primary key (KORISNIKID)
);

/*==============================================================*/
/* Index: KORISNIK_PK                                           */
/*==============================================================*/
create unique index KORISNIK_PK on KORISNIK (
KORISNIKID ASC
);

/*==============================================================*/
/* Table: KORPA                                                 */
/*==============================================================*/
create table KORPA 
(
   KORPAID              integer                        not null,
   KORISNIKID           integer                        not null,
   constraint PK_KORPA primary key (KORPAID)
);

/*==============================================================*/
/* Index: KORPA_PK                                              */
/*==============================================================*/
create unique index KORPA_PK on KORPA (
KORPAID ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_2_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_2_FK on KORPA (
KORISNIKID ASC
);

/*==============================================================*/
/* Table: NARUDZBINA                                            */
/*==============================================================*/
create table NARUDZBINA 
(
   NARUDZBINAID         integer                        not null,
   ADRESAID             integer                        not null,
   KORISNIKID           integer                        not null,
   KORPAID              integer                        not null,
   DATUM                date                           not null,
   SUMA                 float                          not null,
   STATUS               smallint                       not null,
   constraint PK_NARUDZBINA primary key (NARUDZBINAID)
);

/*==============================================================*/
/* Index: NARUDZBINA_PK                                         */
/*==============================================================*/
create unique index NARUDZBINA_PK on NARUDZBINA (
NARUDZBINAID ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_3_FK on NARUDZBINA (
ADRESAID ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_5_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_5_FK on NARUDZBINA (
KORISNIKID ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_8_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_8_FK on NARUDZBINA (
KORPAID ASC
);

/*==============================================================*/
/* Table: PROIZVOD                                              */
/*==============================================================*/
create table PROIZVOD 
(
   PROIZVODID           integer                        not null,
   KATEGORIJAID         integer                        not null,
   SLIKA                varchar(100)                   not null,
   TIP                  varchar(20)                    not null,
   NAZIV		varchar(50)		       not null,
   OPIS                 varchar(100)                   not null,
   CENA                 float                          not null,
   KOLICINA             integer                        not null,
   STATUS               smallint                       not null,
   constraint PK_PROIZVOD primary key (PROIZVODID)
);

/*==============================================================*/
/* Index: PROIZVOD_PK                                           */
/*==============================================================*/
create unique index PROIZVOD_PK on PROIZVOD (
PROIZVODID ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_4_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_4_FK on PROIZVOD (
KATEGORIJAID ASC
);

/*==============================================================*/
/* Table: PROIZVODKORPA                                         */
/*==============================================================*/
create table PROIZVODKORPA 
(
   PROIZVODKORPAID      integer                        not null,
   PROIZVODID           integer                        not null,
   KORPAID              integer                        not null,
   KOLICINA             integer                        not null,
   constraint PK_PROIZVODKORPA primary key (PROIZVODKORPAID)
);

/*==============================================================*/
/* Index: PROIZVODKORPA_PK                                      */
/*==============================================================*/
create unique index PROIZVODKORPA_PK on PROIZVODKORPA (
PROIZVODKORPAID ASC
);

/*==============================================================*/
/* Index: PROIZVODKORPA2_FK                                     */
/*==============================================================*/
create index PROIZVODKORPA2_FK on PROIZVODKORPA (
PROIZVODID ASC
);

/*==============================================================*/
/* Index: PROIZVODKORPA_FK                                      */
/*==============================================================*/
create index PROIZVODKORPA_FK on PROIZVODKORPA (
KORPAID ASC
);

alter table KORPA
   add constraint FK_KORPA_KORPA_KOR_KORISNIK foreign key (KORISNIKID)
      references KORISNIK (KORISNIKID)
      on update restrict
      on delete restrict;

alter table NARUDZBINA
   add constraint FK_NARUDZBI_ADRESA_NA_ADRESA foreign key (ADRESAID)
      references ADRESA (ADRESAID)
      on update restrict
      on delete restrict;

alter table NARUDZBINA
   add constraint FK_NARUDZBI_KORISNIK__KORISNIK foreign key (KORISNIKID)
      references KORISNIK (KORISNIKID)
      on update restrict
      on delete restrict;

alter table NARUDZBINA
   add constraint FK_NARUDZBI_NARUDZBIN_KORPA foreign key (KORPAID)
      references KORPA (KORPAID)
      on update restrict
      on delete restrict;

alter table PROIZVOD
   add constraint FK_PROIZVOD_KATEGORIJ_KATEGORI foreign key (KATEGORIJAID)
      references KATEGORIJA (KATEGORIJAID)
      on update restrict
      on delete restrict;

alter table PROIZVODKORPA
   add constraint FK_PROIZVOD_RELATIONS_PROIZVOD foreign key (PROIZVODID)
      references PROIZVOD (PROIZVODID)
      on update restrict
      on delete restrict;

alter table PROIZVODKORPA
   add constraint FK_PROIZVOD_RELATIONS_KORPA foreign key (KORPAID)
      references KORPA (KORPAID)
      on update restrict
      on delete restrict;

